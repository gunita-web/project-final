import React from 'react';
import ReactDOM from 'react-dom';
//import Header from './Components/Header';

//import Form from './Form'
import Main from './Components/Main'


 


ReactDOM.render(<Main/>,document.getElementById('root'));



