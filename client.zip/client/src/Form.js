import React from 'react'
import Welcome from './Welcome'

 

class Form extends React.Component {

 

    constructor(props){
        super(props)
        this.state = {
            firstName:''
        }

 

        this.firstNameChanged = this.firstNameChanged.bind(this)
        this.inverseWord = this.inverseWord.bind(this)
        this.reverse = this.reverse.bind(this)
    }

 

    firstNameChanged(event){
        //this.state.firstName = event.target.value //This is bad. Use the function so it notifies everyone
        this.setState({
            firstName:event.target.value
        })
        console.log(event.target.value)
        
    }

 

    reverse(s){
        return s.split("").reverse().join("");
    }

 

    inverseWord(){
        console.log('inversing')
        this.setState({
            firstName: this.reverse(this.state.firstName)
        })
    }

 

    render() {
        return (
            <>
                <form>
                    <label htmlFor='fName'>First Name: </label>
                    <input value={this.state.firstName} type='text' onChange={this.firstNameChanged} name='fName' />
                </form>
                <Welcome name={this.state.firstName} inverse={this.inverseWord}  />
           
            </>
        )
    }
}

 

export default Form;