
import React from 'react'


class Welcome extends React.Component {


    constructor(props){
        super(props)
        this.state = {
            name: undefined,
            value: undefined
        }
        
    }


    componentDidMount() {
        const serverUrl = 'https://api.discogs.com/database/search?token=BDisfVlpylOoPNDtUCXWjqywsSaceMFbuOodfRUR'
        fetch(serverUrl, { method: 'GET' })
            .then(response => response.json())

            .then(json => console.log(json))
            // .then(json => this.setState({name:json.name, value:json.value}))
            // .then(json => this.handleResponse(json))


    }


    handleResponse = (jsonResponse) => {
        this.setState({
            name: jsonResponse.name,
            value: jsonResponse.value
        })
    }

    searchDiscog = (event) => {
        const serverUrl = 'https://api.discogs.com/database/search?token=BDisfVlpylOoPNDtUCXWjqywsSaceMFbuOodfRUR&query=' + event.target.value
        fetch(serverUrl, { method: 'GET' })
            .then(response => response.json())

            .then(json => console.log(json))
            // .then(json => this.setState({name:json.name, value:json.value}))
            // .then(json => this.handleResponse(json))

    }



    render() {
        return (
            <>
                <h1>Welcome {this.props.name}</h1>
                <br />
                <button onClick={this.props.inverse} >Inverse</button>
                <hr />
                <label>{this.state.name}</label>
                <br />
                <label>{this.state.value}</label>
                <input type="text" onChange={this.searchDiscog}></input>

             
</>
  )
  }
 
        
}


export default Welcome;









